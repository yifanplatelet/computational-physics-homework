#pragma once
double CalcTime();
